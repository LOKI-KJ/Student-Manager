
<?php
try {
    $pdo = new PDO(
        "mysql:host=localhost;dbname=student_contacts_db;charset=utf8mb4",
        "root",
        ""
    );

    $pdo->setAttribute(
        PDO::ATTR_ERRMODE,
        PDO::ERRMODE_EXCEPTION
    );
} catch (PDOException $e) {
    die("Database connection failed.");
}
?>
