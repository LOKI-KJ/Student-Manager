
<?php
require "db.php";

function safe($value) {
    return htmlspecialchars(
        (string)$value,
        ENT_QUOTES,
        "UTF-8"
    );
}

// CREATE - Add student
if (isset($_POST["add"])) {
    $stmt = $pdo->prepare(
        "INSERT INTO students
        (student_number, full_name, email, section)
        VALUES (?, ?, ?, ?)"
    );

    $stmt->execute([
        trim($_POST["student_number"] ?? ""),
        trim($_POST["full_name"] ?? ""),
        trim($_POST["email"] ?? ""),
        trim($_POST["section"] ?? "")
    ]);

    header("Location: index.php");
    exit;
}

// UPDATE - Edit student
if (isset($_POST["update"])) {
    $stmt = $pdo->prepare(
        "UPDATE students
        SET student_number = ?,
            full_name = ?,
            email = ?,
            section = ?
        WHERE id = ?"
    );

    $stmt->execute([
        trim($_POST["student_number"] ?? ""),
        trim($_POST["full_name"] ?? ""),
        trim($_POST["email"] ?? ""),
        trim($_POST["section"] ?? ""),
        (int)($_POST["id"] ?? 0)
    ]);

    header("Location: index.php");
    exit;
}

// DELETE - Remove student
if (isset($_POST["delete"])) {
    $stmt = $pdo->prepare(
        "DELETE FROM students WHERE id = ?"
    );

    $stmt->execute([
        (int)($_POST["id"] ?? 0)
    ]);

    header("Location: index.php");
    exit;
}

// READ - View all students
$students = $pdo->query(
    "SELECT * FROM students ORDER BY id"
)->fetchAll(PDO::FETCH_ASSOC);

// Select student to edit
$edit = null;

if (isset($_GET["edit"])) {
    $stmt = $pdo->prepare(
        "SELECT * FROM students WHERE id = ?"
    );
    $stmt->execute([(int)$_GET["edit"]]);
    $edit = $stmt->fetch(PDO::FETCH_ASSOC);
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Student Contact Manager</title>
<style>
body {
    font-family: Arial, sans-serif;
    background: #f3f4f6;
    padding: 30px;
}
.container {
    max-width: 1000px;
    margin: auto;
    background: white;
    padding: 25px;
    border-radius: 10px;
}
input {
    padding: 10px;
    margin: 5px;
}
button {
    padding: 10px;
    cursor: pointer;
}
table {
    width: 100%;
    border-collapse: collapse;
    margin-top: 20px;
}
th, td {
    border: 1px solid #ccc;
    padding: 10px;
    text-align: left;
}
th {
    background: #e5e7eb;
}
</style>
</head>
<body>

<div class="container">

<h2>Student Contact Manager</h2>

<h3>
<?= $edit ? "Edit Student" : "Add Student" ?>
</h3>

<form method="POST">

<?php if ($edit): ?>
<input type="hidden" name="id"
       value="<?= safe($edit["id"]) ?>">
<?php endif; ?>

<input type="text" name="student_number"
       placeholder="Student Number"
       value="<?= safe($edit["student_number"] ?? "") ?>"
       required>

<input type="text" name="full_name"
       placeholder="Full Name"
       value="<?= safe($edit["full_name"] ?? "") ?>"
       required>

<input type="email" name="email"
       placeholder="Email Address"
       value="<?= safe($edit["email"] ?? "") ?>"
       required>

<input type="text" name="section"
       placeholder="Section"
       value="<?= safe($edit["section"] ?? "") ?>"
       required>

<?php if ($edit): ?>
<button type="submit" name="update">
    Update Student
</button>
<a href="index.php">Cancel</a>
<?php else: ?>
<button type="submit" name="add">
    Add Student
</button>
<?php endif; ?>

</form>

<h3>Student Records</h3>

<table>
<tr>
    <th>ID</th>
    <th>Student Number</th>
    <th>Full Name</th>
    <th>Email</th>
    <th>Section</th>
    <th>Actions</th>
</tr>

<?php foreach ($students as $student): ?>
<tr>
    <td><?= safe($student["id"]) ?></td>
    <td><?= safe($student["student_number"]) ?></td>
    <td><?= safe($student["full_name"]) ?></td>
    <td><?= safe($student["email"]) ?></td>
    <td><?= safe($student["section"]) ?></td>
    <td>
        <a href="?edit=<?= (int)$student["id"] ?>">
            Edit
        </a>

        <form method="POST" style="display:inline">
            <input type="hidden" name="id"
                   value="<?= safe($student["id"]) ?>">

            <button type="submit" name="delete"
              onclick="return confirm('Delete this student?')">
                Delete
            </button>
        </form>
    </td>
</tr>
<?php endforeach; ?>

</table>
</div>
</body>
</html>
